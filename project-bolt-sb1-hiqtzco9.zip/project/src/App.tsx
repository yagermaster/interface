import React, { useState } from 'react';
import { BookSearch } from './components/BookSearch';
import { Header } from './components/Header';
import { BookList } from './components/BookList';
import { Matches } from './components/Matches';
import { SignInModal } from './components/SignInModal';

function App() {
  const [isSignInOpen, setIsSignInOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gradient-to-b from-amber-50 to-white">
      <Header onSignIn={() => setIsSignInOpen(true)} />
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            <BookSearch />
            <BookList />
          </div>
          <div className="lg:col-span-1">
            <Matches />
          </div>
        </div>
      </main>
      <SignInModal isOpen={isSignInOpen} onClose={() => setIsSignInOpen(false)} />
    </div>
  );
}

export default App;