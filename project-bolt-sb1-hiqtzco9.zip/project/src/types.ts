export interface User {
  id: string;
  name: string;
  email: string;
  preferredGenres: string[];
  location: string;
  avatar: string;
}

export interface Book {
  id: string;
  title: string;
  author: string;
  genre: string;
  condition: 'New' | 'Like New' | 'Very Good' | 'Good' | 'Fair';
  description: string;
  ownerId: string;
  coverImage: string;
  status: 'Available' | 'Reserved' | 'Exchanged';
}

export interface Match {
  userId: string;
  matchScore: number;
  commonGenres: string[];
  availableBooks: Book[];
}