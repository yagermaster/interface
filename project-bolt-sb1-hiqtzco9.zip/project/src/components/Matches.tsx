import React from 'react';
import { Users, BookOpen } from 'lucide-react';

export function Matches() {
  const matches = [
    {
      id: '1',
      name: 'Emma Wilson',
      avatar: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&q=80&w=100',
      commonGenres: ['Fiction', 'Mystery'],
      booksCount: 3,
      matchScore: 85
    },
    {
      id: '2',
      name: 'David Park',
      avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&q=80&w=100',
      commonGenres: ['Science Fiction', 'Fantasy'],
      booksCount: 5,
      matchScore: 78
    }
  ];

  return (
    <div className="bg-white rounded-lg shadow-sm p-4">
      <div className="flex items-center space-x-2 mb-4">
        <Users className="h-5 w-5 text-amber-600" />
        <h2 className="text-xl font-semibold text-gray-900">Your Matches</h2>
      </div>

      <div className="space-y-4">
        {matches.map((match) => (
          <div key={match.id} className="flex items-center space-x-4 p-3 hover:bg-amber-50 rounded-lg transition-colors">
            <img
              src={match.avatar}
              alt={match.name}
              className="w-12 h-12 rounded-full"
            />
            
            <div className="flex-1">
              <h3 className="font-medium text-gray-900">{match.name}</h3>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <span className="flex items-center">
                  <BookOpen className="h-4 w-4 mr-1" />
                  {match.booksCount} books
                </span>
                <span className="text-amber-600">{match.matchScore}% match</span>
              </div>
              <div className="flex flex-wrap gap-1 mt-1">
                {match.commonGenres.map((genre) => (
                  <span key={genre} className="px-2 py-0.5 bg-amber-100 text-amber-800 text-xs rounded-full">
                    {genre}
                  </span>
                ))}
              </div>
            </div>
            
            <button className="px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 transition-colors text-sm">
              Connect
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}