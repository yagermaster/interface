import React, { useRef } from 'react';
import { BookOpen, UserCircle, Bell } from 'lucide-react';

interface HeaderProps {
  onSignIn: () => void;
}

export function Header({ onSignIn }: HeaderProps) {
  const userButtonRef = useRef<HTMLButtonElement>(null);

  return (
    <header className="bg-white shadow-sm">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-2">
            <BookOpen className="h-8 w-8 text-amber-600" />
            <span className="text-2xl font-bold text-gray-900">Bokbytte</span>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <a href="#" className="text-gray-700 hover:text-amber-600 flex items-center space-x-1">
              <span>Browse Books</span>
            </a>
            <a href="#" className="text-gray-700 hover:text-amber-600 flex items-center space-x-1">
              <span>My Collection</span>
            </a>
            <a href="#" className="text-gray-700 hover:text-amber-600 flex items-center space-x-1">
              <span>Matches</span>
            </a>
          </nav>

          <div className="flex items-center space-x-4">
            <button className="text-gray-700 hover:text-amber-600">
              <Bell className="h-6 w-6" />
            </button>
            <button 
              ref={userButtonRef}
              className="text-gray-700 hover:text-amber-600" 
              onClick={onSignIn}
            >
              <UserCircle className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}