import React from 'react';
import { Star, MessageCircle } from 'lucide-react';

export function BookList() {
  const books = [
    {
      id: '1',
      title: 'The Midnight Library',
      author: 'Matt Haig',
      genre: 'Fiction',
      condition: 'Like New',
      coverImage: 'https://images.unsplash.com/photo-1544947950-fa07a98d237f?auto=format&fit=crop&q=80&w=400',
      owner: {
        name: 'Sarah Johnson',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=100'
      }
    },
    {
      id: '2',
      title: 'Project Hail Mary',
      author: 'Andy Weir',
      genre: 'Science Fiction',
      condition: 'Very Good',
      coverImage: 'https://images.unsplash.com/photo-1589998059171-988d887df646?auto=format&fit=crop&q=80&w=400',
      owner: {
        name: 'Michael Chen',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&q=80&w=100'
      }
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      {books.map((book) => (
        <div key={book.id} className="bg-white rounded-lg shadow-sm overflow-hidden">
          <div className="aspect-w-3 aspect-h-2">
            <img
              src={book.coverImage}
              alt={book.title}
              className="w-full h-48 object-cover"
            />
          </div>
          <div className="p-4">
            <h3 className="text-lg font-semibold text-gray-900">{book.title}</h3>
            <p className="text-gray-600">{book.author}</p>
            
            <div className="flex items-center mt-2 space-x-2">
              <span className="px-2 py-1 bg-amber-100 text-amber-800 text-sm rounded-full">
                {book.genre}
              </span>
              <span className="px-2 py-1 bg-green-100 text-green-800 text-sm rounded-full">
                {book.condition}
              </span>
            </div>
            
            <div className="flex items-center justify-between mt-4">
              <div className="flex items-center space-x-2">
                <img
                  src={book.owner.avatar}
                  alt={book.owner.name}
                  className="w-8 h-8 rounded-full"
                />
                <span className="text-sm text-gray-600">{book.owner.name}</span>
              </div>
              
              <div className="flex space-x-2">
                <button className="p-2 text-amber-600 hover:bg-amber-50 rounded-full">
                  <Star className="h-5 w-5" />
                </button>
                <button className="p-2 text-amber-600 hover:bg-amber-50 rounded-full">
                  <MessageCircle className="h-5 w-5" />
                </button>
              </div>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}